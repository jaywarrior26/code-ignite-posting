<h2><?= $title ?></h2>

<div class="row">
  <?php foreach($posts as $post) : ?>
  <div class="col s12 m6 l4">
    <div class="card">
      <div class="card-image">
        <img src="<?php echo site_url().'assets/postimages/'.$post['picture'] ?>">
        <span class="card-title"><?php echo $post['title']; ?></span>
      </div>
      <div class="card-content">
        <p><?php echo word_limiter($post['body'], 30); ?></p>
        <span class="badge blue white-text"><?php echo $post['name']; ?></span>
        <small>Posted on:<?php echo $post['created_at']; ?></small>
      </div>
      <div class="card-action">
        <a href="<?php echo site_url('/posts/'. $post['slug']) ?>">Read more.</a>
      </div>
    </div>
  </div>

  <?php endforeach; ?>

  
</div>

