<div class="container">
<h3><?= $title ?></h3>

<div class="row">
    <?php echo validation_errors() ?>
    <?php echo $error ?>
    <?php echo form_open_multipart('posts/edit/'.$post['id']); ?>

      <div class="row">
        <div class="input-field col s12">
          <input id="title" name="title" type="text" value="<?php echo $post['title'] ?>" class="validate">
          <label for="title">Title</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <textarea id="body" name="body" class="materialize-textarea"><?php echo $post['body'] ?></textarea>
          <label for="body">Body</label>
        </div>
      </div>

      <div class="row">
        <div class="input-field col s12">
          <select name="category">
            <?php foreach($categories as $category) : ?>
            <?php
              if($category['id'] === $post['category_id']) {
                echo '<option value="'.$category['id'].'" selected>'.$category['name'].'</option>';
              } else {
                echo '<option value="'.$category['id'].'" selected>'.$category['name'].'</option>';
              }
            ?>
            
            <?php endforeach ?>
          </select>
          <label>Select Category</label>
        </div>
      </div>

      <input type="hidden" name="curPic" value="<?= $post['picture'] ?>">
      <div class="row">
        <div class="file-field input-field col s12">
          <div class="btn">
            <span>File</span>
            <input type="file" name="postpic">
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" type="text">
          </div>
        </div>
      </div>
      

      <button type="submit" class="waves-effect waves-light btn">Submit</button>
    </form>
  </div>
</div>


<script>
  document.addEventListener('DOMContentLoaded', function() {
    let elems = document.querySelectorAll('select');
    let instances = M.FormSelect.init(elems, {});
  });
</script>