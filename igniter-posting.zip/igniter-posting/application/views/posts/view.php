<div class="container">
  <div class="col">
    <h2 class="header"><?php echo $post['title']; ?></h2>
    <div class="card horizontal">
      <div class="card-image">
        <img src="<?php echo site_url().'assets/postimages/'.$post['picture'] ?>">
      </div>
      <div class="card-stacked">
        <div class="card-content">
          <p><?php echo $post['body']; ?></p>
          <span class="badge blue white-text"><?php echo $post['name']; ?></span>
          <small>Posted on: <?php echo $post['created_at']; ?></small>
        </div>
        <div class="card-action">
          <a href="<?php echo base_url() ?>posts/delete/<?php echo $post['id'] ?>" class="waves-effect waves-light btn red">delete</a>
          <a href="<?php echo base_url() ?>posts/edit/<?php echo $post['id'] ?>" class="waves-effect waves-light btn blue">edit</a>
        </div>
      </div>
    </div>
  </div>
</div>






