<?php

  class Posts extends CI_Controller {
    Public function index(){

      $data['title'] = "Latest Post";

      $data['posts'] = $this->post_model->get_posts();
      $this->load->helper('text');
      $this->load->view('templates/header');
      $this->load->view('posts/index', $data);
      $this->load->view('templates/footer');
    }
    
    public function view($slug = NULL) {
      $data['post'] = $this->post_model->get_posts($slug);
      if(empty($data['post'])){
        show_404();
      }
      $this->load->helper('text');
      $data['title'] = $data['post']['title'];
      $this->load->view('templates/header');
      $this->load->view('posts/view', $data);
      $this->load->view('templates/footer');
    }

    public function create() {
      $data['title'] = 'Create Post';
      $data['error'] = '';

      $this->form_validation->set_rules('title', 'Title', 'required');
      $this->form_validation->set_rules('body', 'Body', 'required');

      
      if ($this->form_validation->run() === FALSE)
      {
        $data['categories'] = $this->post_model->get_category();
        $this->load->view('templates/header');
        $this->load->view('posts/create', $data);
        $this->load->view('templates/footer');
      }
      else 
      {
        $config['upload_path']          = './assets/postimages/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 2048;

        $this->load->library('upload', $config);

        if($this->upload->do_upload('postpic')) {
          $fileData = $this->upload->data();
          $result = $this->post_model->create_post($fileData['file_name']);
          if($result['success']){
            echo "<script>
              window.location = '".base_url()."posts/".$result['slug']."'
            </script>";
          }
        } else {
          $data['error'] = $this->upload->display_errors();
          $this->load->view('templates/header');
          $this->load->view('posts/create', $data);
          $this->load->view('templates/footer');
        }
        
      }
      
    }

    public function delete($slug = NULL) {
      $success = $this->post_model->delete_post($slug);
      if($success){
        redirect('posts');
      }
    }

    public function edit($id){
      $data['post'] = $this->post_model->get_posts($id, true);
      
      
      if(empty($data['post'])){
        show_404();
      }

      $data['error'] = '';
      if(isset($_SERVER["CONTENT_LENGTH"]) && $_SERVER["CONTENT_LENGTH"] > 8388608) {
        echo "<script>
          alert('file size is too big');
          window.location = '';
        </script>";
      }

      $data['categories'] = $this->post_model->get_category();

      $data['title'] = 'Edit Post';

      $this->form_validation->set_rules('title', 'Title', 'required');
      $this->form_validation->set_rules('body', 'Body', 'required');

      if ($this->form_validation->run() === FALSE)
      {
        $this->load->view('templates/header');
        $this->load->view('posts/edit', $data);
        $this->load->view('templates/footer');
      } else {

        $fileEmpty = $_FILES['postpic']['error'] === 4;
        
       

        $config['upload_path']          = './assets/postimages/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 2048;

        $this->load->library('upload', $config);

        if($fileEmpty || $this->upload->do_upload('postpic')) {
          $filename = "";
          if(!$fileEmpty){
            $fileData = $this->upload->data();
            $this->load->helper('file');
            unlink('./assets/postimages/'.$this->input->post('curPic'));
            $filename = $fileData['file_name'];
          }

          $this->post_model->update_post($id, $filename);
          redirect('posts/'.$result['slug']);

        } else {
          $data['error'] = $this->upload->display_errors();
          $this->load->view('templates/header');
          $this->load->view('posts/edit', $data);
          $this->load->view('templates/footer');
        }

      }
    }
  }
  