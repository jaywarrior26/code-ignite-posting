<?php

class Post_model extends CI_Model {
  public function __construct(){
    $this->load->database();
  }

  public function get_posts($slug = false, $byId = false){
    if($slug === false) {
      $query = $this->db->query('SELECT p.*, c.name  FROM posts p LEFT JOIN category c ON p.category_id = c.id ORDER BY p.id DESC');
      return $query->result_array();
    }

    $query;
    if($byId) { 
      $this->db->select('p.*, c.name');
      $this->db->from('posts p'); 
      $this->db->join('category c', 'p.category_id = c.id', 'left');
      $this->db->where('p.id', $slug);
      $query = $this->db->get();
    } else {
      $this->db->select('p.*, c.name');
      $this->db->from('posts p'); 
      $this->db->join('category c', 'p.category_id = c.id', 'left');
      $this->db->where('p.slug', $slug);
      $query = $query = $this->db->get();
    }

    return $query->row_array();
  }

  public function create_post($file_name = ''){
    $slug = url_title($this->input->post('title'));

    $data = array(
      'picture' => $file_name,
      'title' => $this->input->post('title'),
      'slug' => $slug,
      'body' => $this->input->post('body'),
      'category_id' => $this->input->post('category')
    );

    return array('success' => $this->db->insert('posts', $data), 'slug' => $slug);
  }

  public function get_category() {
    $this->db->order_by('id', 'desc');
    $query = $this->db->get('category');
    return $query->result_array();
  }

  public function delete_post($id = 0){
    $this->db->where('id', $id);
    return $this->db->delete('posts');
  }

  public function update_post($id, $file_name){

    $slug = url_title($this->input->post('title'));

    $data = array(
      'title' => $this->input->post('title'),
      'slug' => $slug,
      'body' => $this->input->post('body'),
      'category_id' => $this->input->post('category')
    );

    if($file_name){
      $data['picture'] = $file_name;
    }

    $this->db->where('id', $id);
    return $this->db->update('posts', $data);
  }
}